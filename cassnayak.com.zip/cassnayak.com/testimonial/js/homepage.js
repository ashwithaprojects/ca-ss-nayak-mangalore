jQuery(function($) {
    "use strict";

    var SLZ = window.SLZ || {};


    /*=======================================
    =            SAMPLE FUNCTION            =
    =======================================*/
    SLZ.initSlick = function() {
        $(".testimonial_slider").on('init', function() {
            $(".testimonial_slider ul.slick-dots li button").each(function() {
                if (parseInt($(this).text()) < 10) {
                    $(this).html("0" + $(this).html());
                }
            });
        });

        $(".testimonial_slider").slick({
            arrows: false,
            dots: true,
            infinite: false,
            fade: true,
			autoplay: true,
            adaptiveHeight: true
        });

    };


    /*======================================
    =            INIT FUNCTIONS            =
    ======================================*/

    $(document).ready(function() {
        SLZ.initSlick();
    });


});

  const logo = document.querySelector('.mobile-header .logo')
const hamburger = document.querySelector('#hamburger')
const menu = document.querySelector('.mobile-menu')
const body = document.querySelector('body')

hamburger.addEventListener('click', function() {  
  var isOpening = menu.classList.contains('open')
    
  this.classList.toggle('is-active')
  menu.classList.toggle('open')
  
  logo.classList.toggle('menu-open')  
  body.classList.toggle('lock-overflow-on-mobile')
})